import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from streamlit_mic_recorder import speech_to_text

from services.api_client import (
    get_latest, get_history, get_weather, 
    post_device_command, post_process_text_to_device
)

# Configuration & Page Setup
st.set_page_config(page_title="Core2 Intelligence", page_icon="🌌", layout="wide", initial_sidebar_state="collapsed")

# Fetch Data
with st.spinner("Fetching data..."):
    latest = get_latest() or {}
    weather = get_weather("Lausanne,CH")

forecast_data = weather.get("forecast", {})
forecast = forecast_data.get("daily", []) if isinstance(forecast_data, dict) else forecast_data
current_weather = weather.get("current", {})

import datetime
def get_weather_gradient(condition: str, is_day: bool) -> str:
    cond = condition.lower() if condition else ""
    if "clear" in cond:
        if is_day:
            return "linear-gradient(to bottom, #4facfe 0%, #00f2fe 100%)"
        else:
            return "linear-gradient(to bottom, #09203f 0%, #537895 100%)"
    elif "cloud" in cond or "mist" in cond or "fog" in cond:
        if is_day:
            return "linear-gradient(to bottom, #8e9eab 0%, #eef2f3 100%)"
        else:
            return "linear-gradient(to bottom, #2c3e50 0%, #3498db 100%)"
    elif "rain" in cond or "drizzle" in cond:
        return "linear-gradient(to bottom, #4b6cb7 0%, #182848 100%)"
    elif "snow" in cond:
        return "linear-gradient(to bottom, #e6dada 0%, #274046 100%)"
    elif "thunder" in cond:
        return "linear-gradient(to bottom, #141e30 0%, #243b55 100%)"
    else:
        return "linear-gradient(to bottom, #050b14 0%, #0a192f 100%)"

try:
    now = datetime.datetime.now()
    is_day = 6 <= now.hour <= 20
except Exception:
    is_day = True

bg_gradient = get_weather_gradient(current_weather.get("condition", ""), is_day)

# Inject Global CSS
st.markdown(f"""
<style>
    /* Dynamic Weather Background */
    .stApp {{
        background: {bg_gradient} !important;
        background-size: cover;
        background-attachment: fixed;
    }}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>
    /* True single page app */
    .block-container {
        padding-top: 3rem !important;
        padding-bottom: 2rem !important;
        padding-left: 4rem !important;
        padding-right: 4rem !important;
        max-width: 100% !important;
    }
    header[data-testid="stHeader"] { display: none !important; }
    footer { display: none !important; }
    section[data-testid="stSidebar"] { display: none !important; }
    div[data-testid="collapsedControl"] { display: none !important; }
    button[kind="header"] { display: none !important; }
    
    /* Tabs Styling */
    div[data-testid="stTabs"] {
        background: rgba(15, 23, 42, 0.6);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 16px;
        padding: 10px 24px 24px 24px;
        margin-bottom: 24px;
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
    }
    button[data-baseweb="tab"] {
        background-color: transparent !important;
        color: rgba(255,255,255,0.6) !important;
        font-weight: 600 !important;
    }
    button[data-baseweb="tab"][aria-selected="true"] {
        color: white !important;
    }
    div[data-baseweb="tab-list"] {
        border-bottom: 1px solid rgba(255, 255, 255, 0.1) !important;
        margin-bottom: 15px;
    }
    div[data-baseweb="tab-highlight"] {
        background-color: #38bdf8 !important;
    }
    
    /* Refined Glassmorphism */
    .glass-box {
        background: rgba(15, 23, 42, 0.6); /* Elegant Navy blue base */
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 16px;
        padding: 30px;
        margin-bottom: 30px;
        color: white;
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
    }
    
    .section-title {
        font-family: 'Outfit', -apple-system, sans-serif;
        font-size: 1.2rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        margin-bottom: 25px;
        color: rgba(255, 255, 255, 0.9);
    }
    
    .metric-grid {
        display: flex;
        align-items: flex-start;
        width: 100%;
        overflow-x: auto;
        padding-bottom: 15px;
        gap: 60px;
        justify-content: space-between;
    }
    /* Hide scrollbar for a cleaner look */
    .metric-grid::-webkit-scrollbar {
        height: 6px;
    }
    .metric-grid::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 4px;
    }
    .metric-grid::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.2);
        border-radius: 4px;
    }
    .metric-item {
        flex: 0 0 auto;
        min-width: 130px;
    }
    .metric-value {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 3.5rem;
        font-weight: 700;
        margin-bottom: 4px;
        line-height: 1.2;
    }
    .metric-label {
        font-size: 1rem;
        color: white;
        text-transform: uppercase;
        letter-spacing: 1.5px;
    }
    .metric-sub {
        font-size: 0.75rem;
        color: rgba(255, 255, 255, 0.5);
        margin-top: 4px;
    }
</style>
""", unsafe_allow_html=True)

# ----------------- SESSION STATE -----------------
if "page" not in st.session_state:
    st.session_state.page = "main"

# ----------------- MAIN PAGE ---------------------
if st.session_state.page == "main":
    
    # Header Row
    col_title, col_btns = st.columns([5, 1])
    with col_title:
        st.markdown("<h1 style='font-family: -apple-system, sans-serif; font-weight: 800; font-size: 3rem; color: white; margin-bottom: 0; padding-bottom: 10px;'>WELCOME BACK.</h1>", unsafe_allow_html=True)
    with col_btns:
        st.markdown("<div style='margin-top: 15px;'></div>", unsafe_allow_html=True)
        if st.button("🎛️ Remote Control", use_container_width=True):
            st.session_state.page = "remote"
            st.rerun()

    def icon_to_emoji(icon_code):
        mapping = {
            "01d": "☀️", "01n": "🌙",
            "02d": "⛅", "02n": "☁️",
            "03d": "☁️", "03n": "☁️",
            "04d": "☁️", "04n": "☁️",
            "09d": "🌧️", "09n": "🌧️",
            "10d": "🌦️", "10n": "🌧️",
            "11d": "⛈️", "11n": "⛈️",
            "13d": "❄️", "13n": "❄️",
            "50d": "🌫️", "50n": "🌫️"
        }
        return mapping.get(icon_code, "☁️")

    # INDOOR TELEMETRY ROW (Pure HTML inside glass-box)
    t = latest.get('temperature')
    temp = f"{t:.1f}" if t is not None else "--"
    h = latest.get('humidity')
    hum = f"{h:.1f}" if h is not None else "--"
    v = latest.get('tvoc')
    tvoc = f"{int(v)}" if v is not None else "--"
    e = latest.get('eco2')
    eco2 = f"{int(e)}" if e is not None else "--"
    p = latest.get('pir')
    if p is True:
        pir_disp = "DETECTED"
        pir_color = "#38bdf8"
    elif p is False:
        pir_disp = "CLEAR"
        pir_color = "white"
    else:
        pir_disp = "--"
        pir_color = "white"

    # Outdoor data
    cw_temp = current_weather.get("temp")
    out_temp = f"{cw_temp:.1f}" if cw_temp is not None else "--"
    cw_hum = current_weather.get("humidity")
    out_hum = f"{cw_hum}" if cw_hum is not None else "--"
    cw_wind = current_weather.get("wind_speed")
    out_wind = f"{cw_wind}" if cw_wind is not None else "--"
    cw_press = current_weather.get("pressure")
    out_press = f"{cw_press}" if cw_press is not None else "--"

    tab_in, tab_out = st.tabs(["INDOOR SENSORS", "OUTDOOR WEATHER"])
    
    with tab_in:
        st.markdown(f"""
        <div class="metric-grid" style="padding-top: 10px;">
            <div class="metric-item">
                <div class='metric-label'>INDOOR TEMP</div>
                <div class='metric-value'>{temp}°C</div>
                <div class='metric-sub'>Indoor Sensor</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>INDOOR HUMIDITY</div>
                <div class='metric-value'>{hum}%</div>
                <div class='metric-sub'>Optimal: 40-60%</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>TVOC</div>
                <div class='metric-value'>{tvoc} ppb</div>
                <div class='metric-sub'>Target: < 220 ppb</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>eCO₂</div>
                <div class='metric-value'>{eco2} ppm</div>
                <div class='metric-sub'>Target: < 1000 ppm</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>MOTION</div>
                <div class='metric-value' style='color: {pir_color}; font-size: 2.2rem; padding-top: 8px;'>{pir_disp}</div>
                <div class='metric-sub'>PIR Sensor</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
    with tab_out:
        st.markdown(f"""
        <div class="metric-grid" style="padding-top: 10px;">
            <div class="metric-item">
                <div class='metric-label'>OUTDOOR TEMP</div>
                <div class='metric-value'>{out_temp}°C</div>
                <div class='metric-sub'>Weather API</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>OUTDOOR HUMIDITY</div>
                <div class='metric-value'>{out_hum}%</div>
                <div class='metric-sub'>Weather API</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>WIND SPEED</div>
                <div class='metric-value'>{out_wind} <span style="font-size:1rem;">m/s</span></div>
                <div class='metric-sub'>Weather API</div>
            </div>
            <div class="metric-item">
                <div class='metric-label'>PRESSURE</div>
                <div class='metric-value'>{out_press} <span style="font-size:1rem;">hPa</span></div>
                <div class='metric-sub'>Weather API</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # BOTTOM ROW (Charts & Forecast)
    bot1, bot2 = st.columns([2.5, 1])
    
    with bot1:
        st.markdown("<div style='display:flex; justify-content: flex-end; margin-bottom: -15px; position: relative; z-index: 10;'>", unsafe_allow_html=True)
        col_empty, col_sel = st.columns([4, 1])
        with col_sel:
            time_range = st.selectbox("History", ["24 HOURS", "7 DAYS", "1 MONTH"], label_visibility="collapsed")
        st.markdown("</div>", unsafe_allow_html=True)
        
        hours_map = {"24 HOURS": 24, "7 DAYS": 168, "1 MONTH": 744}
        with st.spinner("Loading charts..."):
            history = get_history(hours_map[time_range])
            
        if history:
            df = pd.DataFrame(history)
            df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
            df = df.dropna(subset=["timestamp"]).sort_values("timestamp")
            
            # No manual glass-box container needed, stTabs CSS does it automatically
            tab1, tab2, tab3 = st.tabs(["📈 Temperature", "📉 Humidity", "📊 Air Quality"])
            
            def style_fig(fig):
                fig.update_layout(
                    paper_bgcolor="rgba(0,0,0,0)",
                    plot_bgcolor="rgba(0,0,0,0)",
                    margin=dict(l=20, r=20, t=30, b=20), height=420,
                    legend=dict(orientation="h", y=1.1, font=dict(color="rgba(255,255,255,0.8)")),
                    xaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.1)", zeroline=False, tickfont=dict(color="rgba(255,255,255,0.5)")),
                    yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.1)", zeroline=False, tickfont=dict(color="rgba(255,255,255,0.5)"))
                )
                return fig
                
            with tab1:
                fig1 = go.Figure()
                if "temperature" in df.columns:
                    fig1.add_trace(go.Scatter(x=df["timestamp"], y=df["temperature"], name="Indoor Temp (°C)", line=dict(color="#38bdf8", width=3, shape="spline"), mode="lines"))
                # Plot outdoor_temp if it exists AND contains any non-null values
                if "outdoor_temp" in df.columns and df["outdoor_temp"].notna().any():
                    fig1.add_trace(go.Scatter(x=df["timestamp"], y=df["outdoor_temp"], name="Outdoor Temp (°C)", line=dict(color="rgba(255,255,255,0.5)", width=2, dash="dot", shape="spline"), mode="lines"))
                st.plotly_chart(style_fig(fig1), use_container_width=True)
                
            with tab2:
                fig2 = go.Figure()
                if "humidity" in df.columns:
                    fig2.add_trace(go.Scatter(x=df["timestamp"], y=df["humidity"], name="Indoor Humidity (%)", line=dict(color="#34d399", width=3, shape="spline"), fill='tozeroy', fillcolor="rgba(52, 211, 153, 0.1)"))
                st.plotly_chart(style_fig(fig2), use_container_width=True)
                
            with tab3:
                fig3 = go.Figure()
                if "tvoc" in df.columns:
                    fig3.add_trace(go.Scatter(x=df["timestamp"], y=df["tvoc"], name="TVOC (ppb)", line=dict(color="#fbbf24", width=3, shape="spline")))
                if "eco2" in df.columns:
                    fig3.add_trace(go.Scatter(x=df["timestamp"], y=df["eco2"], name="eCO2 (ppm)", line=dict(color="#f87171", width=3, shape="spline"), yaxis="y2"))
                f3 = style_fig(fig3)
                f3.update_layout(yaxis2=dict(overlaying="y", side="right", showgrid=False, tickfont=dict(color="#f87171")))
                st.plotly_chart(f3, use_container_width=True)
                

        else:
            st.markdown("<div class='glass-box' style='text-align: center; color: rgba(255,255,255,0.5); padding: 50px 0;'>No historical data available</div>", unsafe_allow_html=True)
        
    with bot2:
        forecast_html = ""
        forecast_7 = forecast[:7] if forecast else []
        if forecast_7:
            global_min = min([d.get('temp_min', 0) for d in forecast_7])
            global_max = max([d.get('temp_max', 10) for d in forecast_7])
            range_span = max(global_max - global_min, 1) # Prevent div by 0
            
            for i, day in enumerate(forecast_7):
                day_min = day.get('temp_min', 0)
                day_max = day.get('temp_max', 0)
                left_pct = (day_min - global_min) / range_span * 100
                width_pct = max((day_max - day_min) / range_span * 100, 5) # Minimum 5% width
                
                if i == 0:
                    day_label = "NOW"
                    date_label = f"<div style='font-size: 0.75rem; color: rgba(255,255,255,0.5); font-weight: 400; margin-top: 2px;'>{datetime.datetime.now().strftime('%b %d')}</div>"
                else:
                    day_label = day.get('day_name', '')[:3]
                    date_label = ""
                
                forecast_html += f"""<div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 23px; color: white; font-size: 1.1rem;'>
<div style='width: 45px; font-weight: 600; color: rgba(255,255,255,0.8); line-height: 1.1;'>{day_label}{date_label}</div>
<div style='color: white; font-size: 1.4rem; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));'>{icon_to_emoji(day.get('icon'))}</div>
<div style='color: rgba(255,255,255,0.6); font-variant-numeric: tabular-nums; font-size: 0.95rem; text-align: right; width: 30px;'>{int(day_min)}°</div>
<div style='flex-grow: 1; height: 6px; background: rgba(0,0,0,0.3); border-radius: 3px; margin: 0 10px; position: relative; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);'>
<div style='position: absolute; left: {left_pct}%; width: {width_pct}%; top: 0; bottom: 0; background: linear-gradient(90deg, #38bdf8, #f59e0b); border-radius: 3px;'></div>
</div>
<div style='font-weight: bold; font-variant-numeric: tabular-nums; width: 30px;'>{int(day_max)}°</div>
</div>"""
        else:
             forecast_html = "<div style='text-align: center; color: rgba(255,255,255,0.5); padding: 50px 0;'>No forecast data</div>"
             
        st.markdown(f"""
<div class="glass-box" style="height: 100%; min-height: 440px;">
    <div class="section-title" style="margin-bottom: 25px;">7-DAY FORECAST</div>
    {forecast_html}
</div>
""", unsafe_allow_html=True)

# ----------------- REMOTE PAGE ---------------------
elif st.session_state.page == "remote":
    st.markdown("""
    <style>
        .m5-container {
            width: 700px;
            margin: 40px auto;
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 20px;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(20px);
            padding: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .m5-title {
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 20px;
            padding: 8px 20px;
            color: #38bdf8;
            font-weight: 600;
            font-size: 1.1rem;
            flex-grow: 1;
            text-align: center;
            margin: 0 15px;
            letter-spacing: 1px;
            background: rgba(255,255,255,0.05);
        }
        .m5-screen {
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            height: 320px;
            background: #0f172a;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin-top: 15px;
            margin-bottom: 25px;
            box-shadow: inset 0 0 20px rgba(0,0,0,0.5);
        }
        .m5-text {
            color: white;
            padding: 20px;
            font-size: 1.4rem;
            font-family: -apple-system, sans-serif;
            text-align: center;
            font-weight: 300;
        }
        .stButton>button {
            border-radius: 50% !important;
            width: 50px !important;
            height: 50px !important;
            display: flex;
            justify-content: center;
            align-items: center;
            background: rgba(255,255,255,0.1) !important;
            border: 1px solid rgba(255,255,255,0.2) !important;
            color: white !important;
            transition: all 0.2s ease !important;
        }
        .stButton>button:hover {
            background: rgba(255,255,255,0.2) !important;
            transform: scale(1.05) !important;
        }
        
        /* Center the mic recorder */
        div[data-testid="stVerticalBlock"] > div > div > div > div > button {
            margin: 0 auto;
        }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="m5-container">', unsafe_allow_html=True)
    
    # Header
    col1, col2, col3 = st.columns([1, 8, 1])
    with col1:
        if st.button("🏠"):
            st.session_state.page = "main"
            st.rerun()
    with col2:
        st.markdown('<div class="m5-title">M5STACK BEDROOM</div>', unsafe_allow_html=True)
    with col3:
        if st.button("⏻"):
            post_device_command("set_brightness", 100) # Simple wake
    
    st.markdown('<div class="m5-screen">', unsafe_allow_html=True)
    
    # Text Area
    if "voice_text" not in st.session_state:
        st.session_state.voice_text = "Click the mic to speak..."
        
    st.markdown(f'<div class="m5-text">{st.session_state.voice_text}</div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Controls (Left, Mic, Right)
    c1, c2, c3, c4, c5 = st.columns([2, 1, 2, 1, 2])
    with c2:
        if st.button("◀"):
            post_device_command("prev_page", 1) # Prev page
    with c3:
        text = speech_to_text(language='fr-FR', start_prompt="🎙️", stop_prompt="🛑", just_once=True, key='STT')
        if text:
            st.session_state.voice_text = f"You: {text}"
            with st.spinner("Thinking..."):
                post_process_text_to_device(text, {"location": "Bedroom"})
            st.rerun()
    with c4:
        if st.button("▶"):
            post_device_command("next_page", 1) # Next page
            
    st.markdown('</div>', unsafe_allow_html=True)
